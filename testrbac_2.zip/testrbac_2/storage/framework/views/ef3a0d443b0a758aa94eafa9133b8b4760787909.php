
<div class="row justify-content-center">
    <div class="col-md-8">
        <table cellpadding="10">
            <tr>
                <td><a href="home">Home</a></td>
                <td><a href="users">Users</a></td>
                <td><a href="roles">Roles</a></td>
                <td><a href="products">Products</a></td>
            </tr>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\testrbac_2\resources\views/layouts/menu.blade.php ENDPATH**/ ?>